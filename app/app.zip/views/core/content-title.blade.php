<h3 class="page-title">
    Blank Page <small>blank page</small>
</h3>