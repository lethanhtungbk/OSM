<div class="form-group">
    <label class="col-md-3 control-label">{{$field['desc']}}</label>
    <div class="col-md-9">
        {{ Form::select($field["name"], $field["value"], array('',''), array('multiple'), null) }}
    </div>
</div>