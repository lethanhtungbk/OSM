<div class="form-group">
    <label class="col-md-3 control-label">Text area</label>
    <div class="col-md-4">
        <textarea class="form-control" rows="5"></textarea>
    </div>
</div>