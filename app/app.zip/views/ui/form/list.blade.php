<div class="form-group">
    <label class="col-md-3 control-label">List</label>
    <div class="col-md-3">
        <select multiple="" class="form-control">
            <option>Option 1</option>
            <option>Option 2</option>
            <option>Option 3</option>
            <option>Option 4</option>
            <option>Option 5</option>
        </select>                   
    </div>
</div>