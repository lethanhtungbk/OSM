<div class="form-group">
    <label class="col-md-3 control-label">Image</label>
    <div class="col-md-3">
        <input type="file" id="exampleInputFile">                    
    </div>
</div>