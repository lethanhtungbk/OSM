<div class="form-group">
    <label class="col-md-3 control-label">Radio</label>
    <div class="col-md-9">
        <div class="radio-list">
            <label class="radio-inline">
                <input type="radio" name="optionsRadios" id="optionsRadios4" value="option1" checked> Option 1 </label>
            <label class="radio-inline">
                <input type="radio" name="optionsRadios" id="optionsRadios5" value="option2"> Option 2 </label>
            <label class="radio-inline">
                <input type="radio" name="optionsRadios" id="optionsRadios6" value="option3" disabled> Disabled </label>
        </div>

    </div>


</div>