<div class="form-group">
    <label class="col-md-3 control-label">Date Picker</label>
    <div class="col-md-3">
        <input class="form-control form-control-inline input-medium date-picker" size="16" type="text" value=""/>

    </div>


</div>