<div class="table-toolbar">
    <div class="btn-group">
        <a id="sample_editable_1_new" class="btn green" href="{{$add}}">
            Add New <i class="fa fa-plus"></i>
        </a>
        <a id="sample_editable_1_new" class="btn blue" href="{{URL::to('setting/field-types-add')}}">
            Remove <i class="fa fa-plus"></i>
        </a>
    </div>
</div>